# FlaskApp
This App will be used to deploy with AWS code pipeline

## Video used
https://www.youtube.com/watch?v=H2MPoxGqzzA&list=PLRFRM3JNuCkvSwseuNwy_z0GuvKOAa1Yc&index=11
